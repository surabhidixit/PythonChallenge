import re


# read the text data from the file and store into an output file



class Test:
    input_string=[]

    def __init__(self,path):
        self.path = path
        self.openfile(path)

    def openfile(self, path):
        with open(path) as file:
            arr = file.read().splitlines()
        self.input_string = arr

    def addwords(self, dict, line):

        tags = line.strip('\\n').split(',')
        #  print tags
        tag_length = len(tags)
        for i in xrange(tag_length - 1):
            for j in xrange(tag_length - 2 - i):
                tag1, tag2 = tags[i], tags[i + j + 1]
                str = r'\b{0}\b.+\b{1}\b'.format(tag1, tag2)
                matches = re.findall(str, line)
                if matches:
                    if (tag1, tag2) in dict.keys():
                        dict[tag1, tag2] += 1
                    else:
                        dict[tag1, tag2] = 1
                else:
                    continue

    def createdict(self):
        mydict = {}
        for line in self.input_string:
            self.addwords(mydict, line)
        return mydict


t = Test("/home/surabhi/Downloads/gene_lists_small.txt")
res = t.createdict()


with open("/home/surabhi/Desktop/OutputCel.txt", 'w') as f:
    for (k,v) in res.items():
        if v>=50:
            f.write(k)
            f.write(' :')
            f.write(v)
            f.write('\n')

